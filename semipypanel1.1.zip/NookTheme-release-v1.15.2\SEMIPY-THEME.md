# Semipy Host Panel — Theme v1.1

Tema total untuk panel (NookTheme v1.15.2), disamakan dengan website billing
**https://beli.semipyhost.my.id**.

> Perubahan **hanya tampilan** (warna, font, radius, shadow, aset brand).
> Tidak ada logika autentikasi, API, permission, database, atau validasi yang
> diubah — jadi tidak menambah permukaan serangan baru.

---

## 1. Ringkasan perubahan

| Area | Sebelum | Sesudah |
|---|---|---|
| Warna dasar | abu netral `#212121` | `#050507` + glow ungu/biru |
| Aksen | biru default | gradient `#894EEF → #3B73ED` |
| Font | IBM Plex Sans | **Plus Jakarta Sans** (lokal) |
| Terminal | putih/hitam default | `#07060D` + ANSI warna brand |
| Login | kartu putih + maskot Pterodactyl | kartu gelap blur + logo Semipy |
| Sidebar server | abu-abu | permukaan brand + ikon gradient |
| Tombol | biru solid | gradient + glow |
| Footer | Nookure | Semipy Host · Powered by Pterodactyl |
| Grafik resource | cyan | ungu brand |
| Radius | kecil | lebih membulat (12–22px) |

Berlaku di **semua halaman**: login, dashboard/daftar server, console,
files, databases, backups, schedules, users, startup, settings, network.

---

## 2. File yang diubah

```
tailwind.config.js                                  (palet + font)
resources/scripts/theme/defaults.ts                 (token theme)
resources/scripts/assets/css/GlobalStylesheet.ts    (body, scrollbar)
resources/scripts/assets/css/sidebar.css            (sidebar server)
resources/scripts/components/App.tsx                (tidak diubah)
resources/scripts/components/auth/LoginContainer.tsx
resources/scripts/components/auth/LoginFormContainer.tsx
resources/scripts/components/elements/PageContentBlock.tsx  (footer)
resources/scripts/components/elements/DropdownMenu.tsx       (menu konteks gelap)
resources/scripts/components/elements/ScreenBlock.tsx       (halaman error/404)
resources/scripts/components/elements/button/style.module.css
resources/scripts/components/elements/inputs/styles.module.css
resources/scripts/components/NavigationBar.tsx      (aksen ungu)
resources/scripts/components/server/console/Console.tsx     (xterm)
resources/scripts/components/server/console/chart.ts        (grafik)
resources/scripts/components/server/files/FileDropdownMenu.tsx
resources/scripts/components/auth/ForgotPasswordContainer.tsx
resources/scripts/components/auth/LoginCheckpointContainer.tsx
resources/scripts/config.ts                         (prompt terminal)
resources/views/templates/wrapper.blade.php         (font + CSS + meta)
resources/views/layouts/admin.blade.php             (footer admin)
config/app.php                                      (default APP_NAME)
public/assets/semipy-theme.css                      (lapisan tema)
public/assets/svgs/semipy-logo.svg                  (logo login)
public/assets/fonts/*.woff2                         (font lokal)
```

Backup file sumber yang diubah tersedia sebagai `*.bak` di sebelah file aslinya
(ikut terhapus kalau kamu build ulang dari zip bersih — zip ini **tidak**
menyertakan `.bak`).

---

## 3. Build & pasang

Zip ini **sudah berisi hasil build** (`public/assets/bundle.*.js` + `manifest.json`),
jadi kamu bisa langsung deploy folder ini ke panel yang ada.

Kalau kamu mengubah source lagi dan ingin rebuild sendiri:

```bash
# di root project
yarn install --frozen-lockfile
yarn build:production
```

Kalau pakai Docker (cara resmi NookTheme), cukup rebuild image:

```bash
docker compose build --no-cache
docker compose up -d
```

Setelah itu:

```bash
php artisan optimize:clear
```

Lalu hard-refresh browser (Ctrl+Shift+R).

`public/assets/semipy-theme.css` dan font tetap terpasang otomatis lewat
`wrapper.blade.php`, jadi tidak perlu setting tambahan.

---

## 4. Rollback

Karena zip bersih, rollback paling aman = deploy ulang `semipypanel1.0.zip`
atau balikkan file `.bak` yang kamu simpan sebelum build:

```bash
cp tailwind.config.js.bak tailwind.config.js
# ...dst
yarn build:production
```

---

## 5. Catatan keamanan

- Tidak ada `eval`, `dangerouslySetInnerHTML`, inline script, atau endpoint baru.
- Font di-**bundle lokal** (`/assets/fonts`), tidak memanggil CDN pihak ketiga.
- `semipy-theme.css` hanya berisi CSS statis; tidak ada `url(javascript:)` /
  `expression()`.
- Footer & logo memakai link `https://semipyhost.my.id` dengan
  `rel="noopener nofollow noreferrer"`.
- `APP_NAME` hanya nilai default; nilai produksi tetap dari `.env` kamu.
- **Wajib** setelah deploy: pastikan `APP_DEBUG=false`, `APP_ENV=production`,
  dan HTTPS aktif.

### Temuan di paket asli (bukan dari perubahan ini)
- `.env.ci` berisi kredensial **testing** (`APP_KEY=SomeRandomString...`).
  File ini tidak dipakai di produksi, tapi sebaiknya jangan ikut di-deploy.
- `.env.example` tidak berisi `APP_NAME`; set manual di `.env`:
  ```
  APP_NAME="Semipy Host"
  ```

---

## 6. Yang belum termasuk

- **Panel admin** (Bootstrap) masih memakai tampilan default NookTheme.
  Hanya teks footer yang diganti. Kalau mau, admin bisa dijadikan dark-theme
  terpisah tanpa menyentuh halaman client.
- **Favicon** masih favicon bawaan. Ganti file di `public/favicons/` dengan
  logo Semipy Host (PNG/ICO ukuran 16/32/180/512 + `favicon.ico`).
- **reCAPTCHA** dan konfigurasi keamanan lain tidak diubah.
