const colors = require('tailwindcss/colors');

/**
 * Semipy Host — brand palette
 * Disamakan dengan https://beli.semipyhost.my.id
 */
const brand = {
    50: '#f3edfe',
    100: '#e7dbfd',
    200: '#cfb7fb',
    300: '#b691f8',
    400: '#a06bf4',
    500: '#894EEF',
    600: '#7136d6',
    700: '#5829ab',
    800: '#401e7d',
    900: '#2a1356',
};

const blue = {
    50: '#eef4ff',
    100: '#dbe7ff',
    200: '#bcd2ff',
    300: '#8fb4ff',
    400: '#5f90fb',
    500: '#3B73ED',
    600: '#2c5bd0',
    700: '#2349a8',
    800: '#1d3b83',
    900: '#172d63',
};

const neutral = {
    50: '#faf9ff',
    100: '#f2efff',
    200: '#e7e3ff',
    300: '#c9c3e6',
    400: '#a29ec0',
    500: '#6f6a8f',
    600: '#3b3363',
    700: '#171232',
    800: '#0e0b1a',
    900: '#050507',
};

module.exports = {
    content: [
        './resources/scripts/**/*.{js,ts,tsx}',
    ],
    theme: {
        extend: {
            fontFamily: {
                sans: ['"Plus Jakarta Sans"', '"IBM Plex Sans"', '"Roboto"', 'system-ui', 'sans-serif'],
                header: ['"Plus Jakarta Sans"', '"IBM Plex Sans"', '"Roboto"', 'system-ui', 'sans-serif'],
                mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
            },
            colors: {
                black: '#050507',
                white: '#ffffff',
                // "primary" dan "blue" dipakai tombol/aksen -> ungu brand
                primary: brand,
                blue: blue,
                violet: brand,
                purple: brand,
                // permukaan gelap brand
                gray: neutral,
                neutral: neutral,
                slate: neutral,
                zinc: neutral,
                orange: colors.orange,
                cyan: colors.cyan,
            },
            fontSize: {
                '2xs': '0.625rem',
            },
            borderRadius: {
                none: '0px',
                sm: '0.375rem',
                DEFAULT: '0.5rem',
                md: '0.5rem',
                lg: '0.75rem',
                xl: '1rem',
                '2xl': '1.25rem',
                '3xl': '1.5rem',
                full: '9999px',
            },
            transitionDuration: {
                250: '250ms',
            },
            borderColor: theme => ({
                default: theme('colors.neutral.400', 'currentColor'),
            }),
        },
    },
    plugins: [
        require('@tailwindcss/line-clamp'),
        require('@tailwindcss/forms')({
            strategy: 'class',
        }),
    ]
};
